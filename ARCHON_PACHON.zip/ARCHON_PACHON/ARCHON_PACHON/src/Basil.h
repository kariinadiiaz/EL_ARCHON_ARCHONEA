#pragma once
#include "Pieza.h"
class Basil
{
	Pieza pieza{ {0,0}, {0,0,0}, 200, Movimiento::volador, 5 };
};

