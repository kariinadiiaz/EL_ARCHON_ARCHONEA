#pragma once
#include "Pieza.h"
class MiguelHernando
{
	Pieza pieza{ {0,0}, {0,0,0}, 250, Movimiento::teletransporte, 3 };
};

