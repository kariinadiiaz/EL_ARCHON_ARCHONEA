#pragma once
#include "Pieza.h"
class Imanol
{
	Pieza pieza{ {0,0}, {0,0,0}, 100, Movimiento::terrestre, 3 };
};

