#pragma once
#include "Pieza.h"
class Delegado
{
	Pieza pieza{ {0,0}, {255,255,255}, 250, Movimiento::teletransporte, 3 };
};

