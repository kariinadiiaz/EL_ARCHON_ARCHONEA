#pragma once
#include "Pieza.h"
class Todo10
{
	Pieza pieza{ {0,0}, {255,255,255}, 250, Movimiento::volador, 4 };
};

