#pragma once
#include "Pieza.h"
class Giuseppe
{
	Pieza pieza{ {0,0}, {0,0,0}, 150, Movimiento::terrestre, 3 };
};

