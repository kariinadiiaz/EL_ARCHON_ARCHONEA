#pragma once
#include "Pieza.h"
class Veterano
{
	Pieza pieza{ {0,0}, {255,255,255}, 300, Movimiento::terrestre, 3 };
};

