#pragma once
#include "Pieza.h"
class Humilde
{
	Pieza pieza{ {0,0}, {255,255,255}, 100, Movimiento::terrestre, 3 };
};

