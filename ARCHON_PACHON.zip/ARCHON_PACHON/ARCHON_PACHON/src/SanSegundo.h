#pragma once
#include "Pieza.h"
class SanSegundo
{
	Pieza pieza{ {0,0}, {0,0,0}, 200, Movimiento::volador, 3 };
};

