#pragma once
#include "Pieza.h"
class HectorMontes
{
	Pieza pieza{ {0,0}, {0,0,0}, 300, Movimiento::terrestre, 3 };
};

