#pragma once
#include "Pieza.h"
class Mago
{
	Pieza pieza{ {0,0}, {255,255,255}, 200, Movimiento::volador, 5 };
};

