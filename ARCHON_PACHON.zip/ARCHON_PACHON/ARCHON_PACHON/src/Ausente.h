#pragma once
#include "Pieza.h"

class Ausente
{
	Pieza pieza{ {0,0}, {255,255,255}, 150, Movimiento::terrestre, 3 };
};

