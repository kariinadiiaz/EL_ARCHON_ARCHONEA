#pragma once
#include "Pieza.h"
class Platero
{
	Pieza pieza{ {0,0}, {0,0,0}, 250, Movimiento::volador, 4 };
};

