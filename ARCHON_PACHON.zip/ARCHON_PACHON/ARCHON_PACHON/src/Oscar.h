#pragma once
#include "Pieza.h"
class Oscar
{
	Pieza pieza{ {0,0}, {0,0,0}, 250, Movimiento::terrestre, 4 };
};

