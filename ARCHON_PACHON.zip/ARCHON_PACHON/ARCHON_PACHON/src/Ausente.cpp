#include "Ausente.h"
