#pragma once
#include "Pieza.h"
class Nocturno
{
	Pieza pieza{ {0,0}, {255,255,255}, 250, Movimiento::terrestre, 4 };
};

